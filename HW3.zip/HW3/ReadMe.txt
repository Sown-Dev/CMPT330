Box Invasion:
The Great Box Army from Boxica is invading your house! Protect your life while taking as many down with you in this arcade shooter.

Controls:
WASD - Move
LMB - Shoot (Semi)
RMG - Shoot (Auto)
R - Reload

Good Luck!